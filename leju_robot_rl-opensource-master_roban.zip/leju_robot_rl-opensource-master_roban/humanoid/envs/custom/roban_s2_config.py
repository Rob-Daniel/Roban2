# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2024 Beijing RobotEra TECHNOLOGY CO.,LTD. All rights reserved.

from itertools import product
from humanoid.envs.base.legged_robot_config import LeggedRobotCfg, LeggedRobotCfgPPO

class RobanS2Cfg(LeggedRobotCfg):
    """
    Configuration class for the Roban S2 humanoid robot.
    """
    class env(LeggedRobotCfg.env):
        # change the observation dim
        frame_stack = 10
        frame_stack_skip = 1
        c_frame_stack = 3
        num_single_obs = 4 + 20 + 20 + 20 + 3 + 2 + 3
        num_observations = int(frame_stack // frame_stack_skip * num_single_obs)
        single_num_privileged_obs = 4 + 20 + 20 + 20 + 20 + 20 + 3 + 3 + 3 + 6 + 1 + 2 + 1 + 3 + 1 + 20 + 20 + 20 + 20 + 20 + 1 + 2 + 1 + 2 + 1 + 2
        num_privileged_obs = int(c_frame_stack * single_num_privileged_obs)
        num_actions = 12 + 8
        num_envs = 4096
        episode_length_s = 24  # episode length in seconds
        use_ref_actions = False  # speed up training by using reference actions
        
    class safety:
        pos_limit = 0.9
        vel_limit = 1.0
        torque_limit = 1.0
    
    class asset(LeggedRobotCfg.asset):
        file = '{LEGGED_GYM_ROOT_DIR}/resources/robots/roban_s21/mjcf/biped_s13.xml'
        velocity_limit = [10, 4.8, 10, 9.6, 6, 6] * 2 + [10] * 8
        
        name = "kuavo"
        foot_name = ["leg_l6_link", "leg_r6_link"]
        knee_name = ["leg_l4_link", "leg_r4_link"]

        terminate_after_contacts_on = [
            'base_link',
            'zarm_l1_link', 'zarm_r1_link',
            'zarm_l2_link', 'zarm_r2_link',
            'zarm_l3_link', 'zarm_r3_link',
        ]
        penalize_contacts_on =[
            'base_link',
            'leg_l1_link', 'leg_r1_link',
            'leg_l2_link', 'leg_r2_link',
            'leg_l3_link', 'leg_r3_link',
            'leg_l4_link', 'leg_r4_link',
            'leg_l5_link', 'leg_r5_link',
            'zarm_l1_link', 'zarm_r1_link',
            'zarm_l2_link', 'zarm_r2_link',
            'zarm_l3_link', 'zarm_r3_link',
            'zarm_l4_link', 'zarm_r4_link',
        ]
        self_collisions = 0  # 1 to disable, 0 to enable...bitwise filter
        flip_visual_attachments = False
        replace_cylinder_with_capsule = False
        fix_base_link = False
        
    class terrain(LeggedRobotCfg.terrain):
        mesh_type = 'plane'
        # mesh_type = 'trimesh'
        curriculum = False
        # rough terrain only:
        measure_heights = False
        # mujoco use the max friction of two contact body, so here is actually the "min friction"
        static_friction = 0.6
        dynamic_friction = 0.6
        terrain_length = 8.
        terrain_width = 8.
        num_rows = 5  # number of terrain rows (levels)
        num_cols = 1  # number of terrain cols (types)
        max_init_terrain_level = 0  # starting curriculum state
        # plane; obstacles; uniform; slope_up; slope_down, stair_up, stair_down
        terrain_proportions = [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0]
        restitution = 0.

        measured_points_x = [-0.3, -0.15, 0., 0.15, 0.3]
        measured_points_y = [-0.15, 0., 0.15]
    
    class noise:
        add_noise = True
        noise_level = 0.6  # scales other values

        class noise_scales:
            dof_pos = 0.05
            dof_vel = 0.5
            ang_vel = 0.1
            lin_vel = 0.05
            lin_acc = 0.5
            last_torque = 0
            quat = 0.03
            height_measurements = 0.1
            
    class init_state(LeggedRobotCfg.init_state):
        pos = [0., 0., 0.67]
        default_euler_xyz = [0., 0., 0.]
        default_joint_angles = {}
        # 左腿参数
        left_values = [-0.412, -0.0437, -0.287, 0.5, -0.2, 0.0]
        # 右腿参数
        right_values = [0.412, 0.0437, 0.287, 0.5, -0.2, 0.0]
        
        # 左腿赋值
        for idx, value in zip(range(1, 7), left_values):
            default_joint_angles[f'leg_l{idx}_joint'] = value
            
        # 右腿赋值
        for idx, value in zip(range(1, 7), right_values):
            default_joint_angles[f'leg_r{idx}_joint'] = value

        left_values_zarm = [0.3, 0.1, 0.0, -0.6]
        right_values_zarm = [0.3, -0.1, 0.0, -0.6]
        
        for idx, value in zip(range(1, 5), left_values_zarm):
            default_joint_angles[f'zarm_l{idx}_joint'] = value
        for idx, value in zip(range(1, 5), right_values_zarm):
            default_joint_angles[f'zarm_r{idx}_joint'] = value
    
    class control(LeggedRobotCfg.control):
        # action scale: target angle = actionScale * action + defaultAngle
        action_scale = 0.25
        
        decimation = 10
        # PD Drive parameters:
        stiffness, damping = {}, {}

        for lr in ['l', 'r']:
            for idx, value in zip(range(1, 7), [100., 100., 100., 150., 40., 40.]):
                stiffness[f'leg_{lr}{idx}_joint'] = value
        for lr, idx in product(['l', 'r'], range(1, 5)):
            stiffness[f'zarm_{lr}{idx}_joint'] = 15.0

        for lr in ['l', 'r']:
            for idx, value in zip(range(1, 7), [2.0, 2.0, 2.0, 4.0, 4.0, 2.0]):
                damping[f'leg_{lr}{idx}_joint'] = value
        for lr, idx in product(['l', 'r'], range(1, 5)):
            damping[f'zarm_{lr}{idx}_joint'] = 3.0

    class sim(LeggedRobotCfg.sim):
        dt = 0.001  # 1000 Hz
        substeps = 1  # 2
        up_axis = 1  # 0 is y, 1 is z

        class physx(LeggedRobotCfg.sim.physx):
            num_threads = 10
            solver_type = 1  # 0: pgs, 1: tgs
            num_position_iterations = 10
            num_velocity_iterations = 0
            contact_offset = 0.01  # [m]
            rest_offset = 0.0  # [m]
            bounce_threshold_velocity = 0.1  # [m/s]
            max_depenetration_velocity = 1.0
            max_gpu_contact_pairs = 2 ** 23  # 2**24 -> needed for 8000 envs and more
            default_buffer_size_multiplier = 5
            # 0: never, 1: last sub-step, 2: all sub-steps (default=2)
            contact_collection = 2
    class domain_rand:
        randomize_base_mass = True
        added_mass_range = [-1., 1.]

        randomize_com_displacement = True
        com_displacement_range = [-0.05, 0.05]

        randomize_link_mass = True
        link_mass_range = [0.9, 1.1]

        randomize_friction = True
        friction_range = [0.0, 1.0]

        randomize_restitution = True
        restitution_range = [0., 0.5]

        randomize_motor_strength = True
        motor_strength_range = [0.8, 1.2]

        randomize_joint_friction = True
        joint_friction_range = [0.1, 2.0]

        randomize_joint_armature = True
        joint_armature_range = [0.1, 2.0]

        randomize_joint_pos_bias = True
        joint_pos_bias_range = [-0.05, 0.05]

        push_robots = True
        push_interval_s = 6.
        push_length_s = [0.05, 0.5]
        max_push = [5, 5, 5, 5, 5, 5]

        randomize_kp = True
        kp_range = [0.8, 1.2]

        randomize_kd = True
        kd_range = [0.8, 1.2]

        randomize_euler_xy_zero_pos = False
        euler_xy_zero_pos_range = [-0.03, 0.03]

        # dynamic randomization
        action_delay = 0.5
        action_noise = 0.02
        
    class commands(LeggedRobotCfg.commands):
        # Vers: lin_vel_x, lin_vel_y, ang_vel_yaw, heading (in heading mode ang_vel_yaw is recomputed from heading error)
        num_commands = 5
        min_lin_vel = 0.
        min_ang_vel = 0.
        resampling_time = 8.  # time before command are changed[s]
        heading_command = False  # if true: compute ang vel command from heading error
        rel_standing_envs = 0.2
        rel_marking_envs = 0.1
        rel_straight_envs = 0.1
        rel_yaw_envs = 0.1
        rel_yvel_envs = 0.1

        class ranges:
            lin_vel_x = [-0.6, 0.6]  # min max [m/s]
            lin_vel_y = [-0.6, 0.6]  # min max [m/s]
            ang_vel_yaw = [-0.6, 0.6]  # min max [rad/s]
            heading = [-3.14, 3.14]
            
    class rewards:
        base_height_target = 0.675
        foot_height = 0.045
        min_dist = 0.20
        max_dist = 0.60
        target_feet_height = 0.03
        # if true negative total rewards are clipped at zero (avoids early termination problems)
        only_positive_rewards = True
        tracking_sigma = 0.25
        height_sigma = 5000
        feet_clearance_sigma = 5000
        max_contact_force = 700  # Forces above this value are penalized

        class scales:
            track_lin_vel_xy = 2.0
            track_ang_vel_z = 0.5
            lin_vel_z = -0.4
            ang_vel_xy = -0.4
            orientation = -2.0
            feet_air_time_clip = 20
            joint_roll_pitch_deviation = -0.2
            joint_arm_deviation = -0.05
            collision = -1.0
            stand_still_without_cmd = -1.0
            base_height = 0.2
            feet_clearance = 1.0
            feet_position = 0.2
            base_acc = 0.2
            dof_vel = -1e-3
            torques = -2e-5
            dof_acc = -1e-6
            dof_swing_power = -1e-3
            foot_slip = -0.05
            action_smoothness = -0.004
            feet_contact_forces = -0.01
            angular_momentum = -5.0
            step_length = 0.2
            feet_touchdown_speed = -0.5

    class normalization:
        class obs_scales:
            lin_vel = 1.
            ang_vel = 1.
            lin_acc = 1
            dof_pos = 1.
            dof_vel = 1
            quat = 1.
            height_measurements = 5.0

        clip_observations = 18.
        clip_actions = 18.
class RobanS2CfgPPO(LeggedRobotCfgPPO):
    seed = 666
    runner_class_name = 'OnPolicyRunner'  # DWLOnPolicyRunner

    class policy:
        init_noise_std = 1.0
        actor_hidden_dims = [512, 256, 128]
        critic_hidden_dims = [512, 256, 128]

    class algorithm(LeggedRobotCfgPPO.algorithm):
        entropy_coef = 0.005
        learning_rate = 1e-3
        num_learning_epochs = 5
        gamma = 0.99
        lam = 0.95
        num_mini_batches = 4
        use_clipped_value_loss = True

    class runner:
        policy_class_name = 'ActorCritic'
        algorithm_class_name = 'PPO'
        num_steps_per_env = 24  # per iteration
        max_iterations = 100000  # number of policy updates

        # logging
        save_interval = 50  # Please check for potential savings every `save_interval` iterations.
        experiment_name = 'Roban_s2_ppo'
        run_name = ''
        # Load and resume
        resume = False
        load_run = -1  # -1 = last run
        checkpoint = -1  # -1 = last saved model
        resume_path = None  # updated from load_run and chkpt)