# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2024 Beijing RobotEra TECHNOLOGY CO.,LTD. All rights reserved.
import os
from collections import deque

from isaacgym.torch_utils import *
from isaacgym import gymtorch, gymapi

import torch
from humanoid.envs import LeggedRobot
from humanoid.envs.base.legged_robot_config import LeggedRobotCfg

from humanoid.utils.terrain import HumanoidTerrain
from humanoid import LEGGED_GYM_ROOT_DIR
from pytorch3d.transforms import euler_angles_to_matrix, matrix_to_euler_angles
from pytorch3d.transforms import quaternion_to_matrix, matrix_to_euler_angles


class RobanS2Env(LeggedRobot):
    def __init__(self, cfg: LeggedRobotCfg, sim_params, physics_engine, sim_device, headless):
        super().__init__(cfg, sim_params, physics_engine, sim_device, headless)
        self.reset_idx(torch.tensor(range(self.num_envs), device=self.device))
        self.frame_stack_skip = self.cfg.env.frame_stack_skip
        self.frame_stack = self.cfg.env.frame_stack
        self.real_frame_stack = self.frame_stack // self.frame_stack_skip

        self.compute_observations()
    
    def _push_robots(self):
        pass # used sample_random_push instead

    def _init_buffers(self):
        super()._init_buffers()
        self.dof_pos_illegal = torch.zeros(self.num_envs, device=self.device, dtype=torch.bool)
        self.base_height = torch.zeros(self.num_envs, device=self.device, dtype=torch.float)
        self.feet_z = torch.zeros(self.num_envs, 2, device=self.device, dtype=torch.float)
        self.last_touchdown_pos = torch.zeros(self.num_envs, 2, device=self.device, dtype=torch.float)
        self.step_length = torch.zeros(self.num_envs, device=self.device)
        self.prev_contact_idx = torch.full((self.num_envs,), -1, dtype=torch.long, device=self.device)
        self.swing_foot_speed_z = torch.zeros(self.num_envs, 2, device=self.device, dtype=torch.float)
    def check_termination(self):
        super().check_termination()
        self.reset_buf |= self.dof_pos_illegal

    def reset_idx(self, env_ids):
        super().reset_idx(env_ids)
        for i in range(self.obs_history.maxlen):
            self.obs_history[i][env_ids] *= 0
        for i in range(self.critic_history.maxlen):
            self.critic_history[i][env_ids] *= 0
        self.lin_acc_filter.reset(env_ids)
        self.dof_pos_illegal[env_ids] = 0
        self.feet_air_time[env_ids] = 0.0
        self.contact_time[env_ids] = 0.0
        self.feet_z[env_ids] = 0.0
        self.last_touchdown_pos[env_ids] = 0.0
        self.prev_contact_idx[env_ids] = -1
        self.step_length[env_ids] = 0.0
        self.base_height[env_ids] = 0.0
        self.angular_momentum[env_ids] = 0.0
        self.contact_forces[env_ids] = 0.0
        self.torques[env_ids] = 0.0
        self.swing_foot_speed_z[env_ids] = 0.0

    def _compute_torques(self, actions):
        actions_scaled = actions * self.cfg.control.action_scale
        p_gains = self.p_gains * self.kp_factors
        d_gains = self.d_gains * self.kd_factors

        p_torque = p_gains * (actions_scaled + self.default_dof_pos - self.dof_pos)
        d_torque = -d_gains * self.dof_vel
        # motor_pos = joint_to_motor_position(self.dof_pos)
        # self.dof_pos_illegal |= torch.isnan(motor_pos).any(dim=-1)
        # motor_pos[self.dof_pos_illegal] = 0
        # d_torque = - get_joint_dumping_torque(self.dof_pos, motor_pos, d_gains, self.dof_vel)
        torques = p_torque + d_torque

        self.dof_pos_illegal |= torch.isnan(torques).any(dim=-1)
        torques[self.dof_pos_illegal] = 0


        if self.cfg.domain_rand.randomize_motor_strength:
            motor_strength_factors = torch_rand_float(self.cfg.domain_rand.motor_strength_range[0],
                                                      self.cfg.domain_rand.motor_strength_range[1],
                                                      (self.num_envs, self.num_actions), device=self.device)
            torques *= motor_strength_factors

        return torch.clip(torques, -self.torque_limits, self.torque_limits)
    
    def _get_noise_scale_vec(self, cfg):
        """ Sets a vector used to scale the noise added to the observations.
            [NOTE]: Must be adapted when changing the observations structure

        Args:
            cfg (Dict): Environment config file

        Returns:
            [torch.Tensor]: Vector of scales used to multiply a uniform distribution in [-1, 1]
        """
        noise_vec = torch.zeros(
            self.cfg.env.num_single_obs, device=self.device)
        self.add_noise = self.cfg.noise.add_noise
        noise_scales = self.cfg.noise.noise_scales
        noise_vec[0: 4] = 0.  # commands
        noise_vec[4: 24] = noise_scales.dof_pos * self.obs_scales.dof_pos
        if isinstance(noise_scales.dof_vel, float):
            noise_vec[24: 44] = noise_scales.dof_vel * self.obs_scales.dof_vel
        else:
            noise_vec[24: 44] = torch.tensor(noise_scales.dof_vel) * self.obs_scales.dof_vel
        noise_vec[44: 64] = noise_scales.last_torque
        noise_vec[64: 67] = noise_scales.ang_vel * self.obs_scales.ang_vel  # ang vel
        noise_vec[67: 69] = noise_scales.quat * self.obs_scales.quat  # euler x,y
        noise_vec[69: 72] = noise_scales.lin_acc * self.obs_scales.lin_acc  # linear acc
        return noise_vec
    
    def step(self, actions):
        actions = torch.clip(actions, -self.cfg.normalization.clip_actions, self.cfg.normalization.clip_actions)
        # dynamic randomization
        delay = torch.rand((self.num_envs, 1), device=self.device) * self.cfg.domain_rand.action_delay
        actions = (1 - delay) * actions + delay * self.actions
        actions += self.cfg.domain_rand.action_noise * torch.randn_like(actions) * actions
        return super().step(actions)

    def compute_observations(self):
        self.get_hip_joint_position()

        contact_mask = self.contact_forces[:, self.feet_indices, 2] > 20.

        self.command_input = torch.cat((self.commands[:, :3], self.commands[:, 4].unsqueeze(1)),dim=1)
        q = (self.dof_pos - self.default_dof_pos + self.joint_pos_bias) * self.obs_scales.dof_pos
        dq = self.dof_vel * self.obs_scales.dof_vel

        self.privileged_obs_buf = torch.cat((
            self.command_input,  # 4
            (self.dof_pos - self.default_joint_pd_target) * \
            self.obs_scales.dof_pos,  # 20
            self.dof_vel * self.obs_scales.dof_vel,  # 20
            (self.last_dof_vel - self.dof_vel) / self.dt * 0.001, # 20 dof acceleration
            self.torques * 0.01, # 20
            self.actions,  # 20
            self.base_lin_vel * self.obs_scales.lin_vel,  # 3
            self.base_ang_vel * self.obs_scales.ang_vel,  # 3
            self.base_euler_xyz * self.obs_scales.quat,  # 3
            self.random_force_value,  # 6
            self.env_frictions,  # 1
            contact_mask,  # 2
            self.body_mass / 27,  # 1
            self.com_displacement, # 3
            self.restitution_coeffs, # 1
            self.joint_pos_bias, # 20
            self.joint_friction_coeffs, # 20
            self.joint_armature_coeffs, # 20
            self.kp_factors, # 20
            self.kd_factors, # 20
            self.angular_momentum[:, 2].unsqueeze(1), # 1
            torch.norm(self.contact_forces[:, self.feet_indices, :], dim=-1) * 0.001, # 2
            self.base_height.unsqueeze(1), # 1
            self.feet_z,  # 2
            self.step_length.unsqueeze(1), # 1
            self.swing_foot_speed_z  # 2
        ), dim=-1)

        base_euler_xy = self.base_euler_xyz.clone()[:, :2] + self.euler_xy_zero_pos
        obs_buf = torch.cat((
            self.command_input,  # 4 = 4D(vel_x, vel_y, aug_vel_yaw, standing)
            q,  # 12D
            dq,  # 12D
            self.actions,
            self.base_ang_vel * self.obs_scales.ang_vel,  # 3
            base_euler_xy * self.obs_scales.quat,  # 2
            self.base_lin_acc * self.obs_scales.lin_acc,  # 3
        ), dim=-1)

        if self.cfg.terrain.measure_heights:
            heights = self.measured_heights* self.obs_scales.height_measurements
            self.privileged_obs_buf = torch.cat((self.privileged_obs_buf, heights), dim=-1)

        if self.add_noise:
            obs_now = obs_buf.clone() + torch.randn_like(obs_buf) * self.noise_scale_vec * self.cfg.noise.noise_level
        else:
            obs_now = obs_buf.clone()
        self.obs_history.append(obs_now)
        self.critic_history.append(self.privileged_obs_buf)

        obs_buf_all = torch.stack([self.obs_history[i]
                                   for i in range(self.obs_history.maxlen)], dim=1)  # N,T,K
        obs_buf_all = obs_buf_all.reshape(self.num_envs, self.real_frame_stack, self.frame_stack_skip, -1)
        self.obs_buf = obs_buf_all[:, :, -1].reshape(self.num_envs, -1)  # N, T*K
        self.privileged_obs_buf = torch.cat([self.critic_history[i] for i in range(self.cfg.env.c_frame_stack)], dim=1)
    
    def _resample_commands(self, env_ids, when_alive=False):
        super()._resample_commands(env_ids, when_alive)
    def analytical_fk_left_leg(self,motor_angles):
        """从电机空间转换到关节空间(左腿)
        
        Args:
            motor_angles: 电机角度 [batch_size, 3]
        
        Returns:
            joint_angles: 关节角度 [batch_size, 3] 
        """
        device = motor_angles.device
        dtype = motor_angles.dtype
        
        # 首先反向应用系数和偏移
        coeffs = torch.tensor([1.0, -1.0, -1.0], device=device, dtype=dtype)
        offsets = torch.tensor([-torch.pi, torch.pi/4, -torch.pi], device=device, dtype=dtype)
        
        # 反向计算YXY欧拉角
        r = motor_angles.clone()
        r = torch.atan2(torch.sin(r), torch.cos(r))  # 标准化角度
        r = (r - offsets) / coeffs
        
        # 从YXY欧拉角转换到旋转矩阵
        R_bt = euler_angles_to_matrix(r, "YXY") 
        
        # 反向应用末端和基座变换
        R_wb = euler_angles_to_matrix(
            torch.tensor([torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_end = euler_angles_to_matrix(
            torch.tensor([-torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        
        # 求解目标旋转矩阵
        R_wt = R_wb.inverse() @ R_bt @ R_end.inverse()
        
        # 转换到YXZ欧拉角
        joint_angles = matrix_to_euler_angles(R_wt, "YXZ")
        
        return joint_angles
    def analytical_fk_right_leg(self,motor_angles):
        """从电机空间转换到关节空间(右腿)
        
        Args:
            motor_angles: 电机角度 [batch_size, 3]
            
        Returns:
            joint_angles: 关节角度 [batch_size, 3]
        """
        device = motor_angles.device
        dtype = motor_angles.dtype
        
        # 首先反向应用系数和偏移
        coeffs = torch.tensor([-1.0, 1.0, 1.0], device=device, dtype=dtype)
        offsets = torch.tensor([0, -torch.pi/4, 0], device=device, dtype=dtype)
        
        # 反向计算YXY欧拉角
        r = motor_angles.clone()
        r = torch.atan2(torch.sin(r), torch.cos(r))  # 标准化角度
        r = (r - offsets) / coeffs
        
        # 从YXY欧拉角转换到旋转矩阵
        R_bt = euler_angles_to_matrix(r, "YXY")
        
        # 反向应用末端和基座变换
        R_wb = euler_angles_to_matrix(
            torch.tensor([-torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_end = euler_angles_to_matrix(
            torch.tensor([torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        
        # 求解目标旋转矩阵
        R_wt = R_wb.inverse() @ R_bt @ R_end.inverse()
        
        # 转换到YXZ欧拉角
        joint_angles = matrix_to_euler_angles(R_wt, "YXZ")
        
        return joint_angles
    def analytical_ik_left_leg(self,euler_angles):
        device = euler_angles.device
        dtype = euler_angles.dtype
        R_wt = euler_angles_to_matrix(euler_angles, "YXZ")
        R_wb = euler_angles_to_matrix(
            torch.tensor([torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_end = euler_angles_to_matrix(
            torch.tensor([-torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_bt = R_wb @ R_wt @ R_end

        r = matrix_to_euler_angles(R_bt, "YXY")
        coeffs = torch.tensor([1.0, -1.0, -1.0], device=device, dtype=dtype)
        offsets = torch.tensor(
            [-torch.pi, torch.pi/4, -torch.pi], device=device, dtype=dtype)
        r = r * coeffs + offsets
        r = torch.atan2(torch.sin(r), torch.cos(r))
        return r
    def analytical_ik_right_leg(self,euler_angles):
        device = euler_angles.device
        dtype = euler_angles.dtype
        R_wt = euler_angles_to_matrix(euler_angles, "YXZ")
        R_wb = euler_angles_to_matrix(
            torch.tensor([-torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_end = euler_angles_to_matrix(
            torch.tensor([torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_bt = R_wb @ R_wt @ R_end

        r = matrix_to_euler_angles(R_bt, "YXY")
        coeffs = torch.tensor([-1.0, 1.0, 1.0], device=device, dtype=dtype)
        offsets = torch.tensor(
            [0, -torch.pi/4, 0], device=device, dtype=dtype)
        r = r * coeffs + offsets
        r = torch.atan2(torch.sin(r), torch.cos(r))
        return r 
    def get_hip_joint_position(self):
        motor_pos = self.dof_pos.clone()
        motor_pos_in = torch.zeros(self.num_envs, 6, device=self.device)
        motor_pos_in[:, :3] = motor_pos[:, 0:3]
        motor_pos_in[:, 3:6] = motor_pos[:, 6:9]
        joint_pos_out = self.analytical_fk_left_leg(motor_pos_in[:, :3])
        joint_pos_out_right = self.analytical_fk_right_leg(motor_pos_in[:, 3:6])
        hip_joint_pos = torch.zeros(self.num_envs, 6, device=self.device)
        hip_joint_pos[:, :3] = joint_pos_out
        hip_joint_pos[:, 3:6] = joint_pos_out_right
        self.hip_joint_pos = hip_joint_pos
    def create_sim(self):
        """ Creates simulation, terrain and evironments
        """
        self.up_axis_idx = 2  # 2 for z, 1 for y -> adapt gravity accordingly
        self.sim = self.gym.create_sim(
            self.sim_device_id, self.graphics_device_id, self.physics_engine, self.sim_params)
        mesh_type = self.cfg.terrain.mesh_type
        if mesh_type in ['heightfield', 'trimesh']:
            self.terrain = HumanoidTerrain(self.cfg.terrain, self.num_envs)
        if mesh_type == 'plane':
            self._create_ground_plane()
        elif mesh_type == 'heightfield':
            self._create_heightfield()
        elif mesh_type == 'trimesh':
            self._create_trimesh()
        elif mesh_type is not None:
            raise ValueError(
                "Terrain mesh type not recognised. Allowed types are [None, plane, heightfield, trimesh]")
        self._create_envs()
    
    def _reward_feet_touchdown_speed(self):
        contact = self.contact_forces[:, self.feet_indices, 2] > 20.0
        not_in_contact = ~contact
        foot_speed_z = self.rigid_state[:, self.feet_indices, 9]  # [num_envs, 2]
        self.swing_foot_speed_z = foot_speed_z * not_in_contact.float()
        feet_swing_downward_mask = self.swing_foot_speed_z < 0
        rew = torch.sum(torch.square(feet_swing_downward_mask * self.swing_foot_speed_z),dim=1)
        return rew

    def _reward_feet_air_time_clip(self):
        standing_mask = self.commands[:, 4] > 0.5
        threshold_min = 0.2
        threshold_max = 0.5
        contact = self.contact_forces[:, self.feet_indices, 2] > 20.0
        self.feet_air_time += self.dt * (~contact).float()
        first_contact = contact & (self.feet_air_time > 0)
        air_time = (self.feet_air_time - threshold_min)*first_contact
        air_time = torch.clamp(air_time, max=threshold_max - threshold_min)
        reward = torch.sum(air_time, dim=1)
        self.feet_air_time[contact] = 0.0
        return torch.where(standing_mask, torch.zeros_like(reward), reward)
    
    def _reward_step_length(self):
        standing_mask = self.commands[:, 4] > 0.5
        foot_pos = self.rigid_state[:, self.feet_indices, :2] # [num_envs, 2, 2]
        contact = self.contact_forces[:, self.feet_indices, 2] > 20.0  # [num_envs, 2]
        num_contacts = torch.sum(contact, dim=1) # [num_envs]
        # Get current contact index: 0 for left, 1 for right, -1 for double/no contact
        contact_idx = torch.full((self.num_envs,), -1, dtype=torch.long, device=self.device)
        single_contact_mask = num_contacts == 1
        contact_idx[single_contact_mask] = contact[single_contact_mask].float().argmax(dim=1)
        # Detect new touchdown: contact_idx changed and is valid (not -1)
        new_touchdown = (contact_idx != self.prev_contact_idx) & (contact_idx != -1) # [num_envs]
        # For those envs, get the position of the contacting foot
        current_touchdown_pos = foot_pos[new_touchdown, contact_idx[new_touchdown], :]  
        step_vec_world = current_touchdown_pos - self.last_touchdown_pos[new_touchdown]
        # Rotate step vector to base frame
        step_vec_world_3d = torch.zeros(step_vec_world.shape[0], 3, device=self.device)
        step_vec_world_3d[:, :2] = step_vec_world  # Convert to 3D by adding z=0
        base_quat_touchdown = self.base_quat[new_touchdown]
        step_vec_base_3d = quat_rotate_inverse(base_quat_touchdown, step_vec_world_3d)  # Rotate to base frame
        step_vec = step_vec_base_3d[:, :2]  # Use only x and y components for step length calculation
        # Calculate the step length in the direction of the command
        cmd_vel = self.commands[new_touchdown, :2]  # [num_envs, 2]
        cmd_dir = cmd_vel / (torch.norm(cmd_vel, dim=1, keepdim=True) + 1e-6)  # Normalize to get direction
        step_proj = torch.sum(step_vec * cmd_dir, dim=1).clip(min=0)  # Project step vector onto command direction
        self.step_length[new_touchdown] = step_proj
        self.last_touchdown_pos[new_touchdown] = current_touchdown_pos
        self.prev_contact_idx = contact_idx.clone() # Update prev_contact_idx for next step
        vel_scale = torch.norm(self.commands[:, :2], dim=1)
        reward = self.step_length * vel_scale
        reward[standing_mask] = 0.0  # No step length reward when standing
        return reward
    
    def _reward_track_lin_vel_xy(self):
        lin_vel_error = torch.sum(torch.square(self.commands[:, :2] - self.base_lin_vel[:, :2]), dim=1)
        return torch.exp(-lin_vel_error/self.cfg.rewards.tracking_sigma)
    
    def _reward_track_ang_vel_z(self):
        ang_vel_error = torch.square(self.commands[:, 2] - self.base_ang_vel[:, 2])
        return torch.exp(-ang_vel_error/self.cfg.rewards.tracking_sigma)
    
    def _reward_lin_vel_z(self):
        return torch.square(self.base_lin_vel[:, 2])

    def _reward_ang_vel_xy(self):
        return torch.sum(torch.square(self.base_ang_vel[:, :2]), dim=1)
    
    def _reward_orientation(self):
        return torch.sum(torch.square(self.projected_gravity[:, :2]), dim=1)
    
    def _reward_dof_swing_power(self):
        contact = self.contact_forces[:, self.feet_indices, 2] > 20.0
        swing_mask = ~contact
        left_leg_power = torch.sum(torch.abs(self.torques[:, :6] * self.dof_vel[:, :6]), dim=1)
        right_leg_power = torch.sum(torch.abs(self.torques[:, 6:12] * self.dof_vel[:, 6:12]), dim=1)
        left_swing_power = left_leg_power * swing_mask[:, 0].float()
        right_swing_power = right_leg_power * swing_mask[:, 1].float()
        return left_swing_power + right_swing_power
    
    def _reward_joint_roll_pitch_deviation(self):
        left_hip_yaw_roll = self.hip_joint_pos[:, 1:3]
        right_hip_yaw_roll = self.hip_joint_pos[:, 4:6]
        left_ankle_roll = 2 * self.dof_pos[:, 5]
        right_ankle_roll = 2 * self.dof_pos[:, 11]
        sum_deviation = torch.sum(torch.abs(left_hip_yaw_roll), dim=1) + \
            torch.sum(torch.abs(right_hip_yaw_roll), dim=1) + \
            torch.abs(left_ankle_roll) + \
            torch.abs(right_ankle_roll)

        return sum_deviation
    
    def _reward_joint_arm_deviation(self):
        arm_pos = self.dof_pos[:, 12:20]
        ref_arm_pos = self.default_dof_pos[:, 12:20]
        weight = torch.tensor([1.0, 10, 10, 1.0] * 2, device=self.device)
        sum_deviation = torch.sum(torch.abs(arm_pos - ref_arm_pos) * weight, dim=1)
        
        return sum_deviation
    
    def _reward_angular_momentum(self):
        link_relative_pos = self.rigid_state[:, 1:, :3] - self.root_states[:, :3].unsqueeze(1) # exclude base link [self.num_envs, self.num_dofs, 3]
        base_quat_expanded = self.base_quat.unsqueeze(1).expand(-1, 22, -1)  # [self.num_envs, self.num_dofs, 4]
        base_quat_flat = base_quat_expanded.reshape(-1, 4)  # [self.num_envs*self.num_dofs, 4]

        link_lin_vel = self.rigid_state[:, 1:, 7:10]  # [self.num_envs, self.num_dofs, 3]
        link_lin_vel_flat = link_lin_vel.reshape(-1, 3)  # [self.num_envs*self.num_dofs, 3]
        link_body_lin_vel_flat = quat_rotate_inverse(base_quat_flat, link_lin_vel_flat)  # [self.num_envs*self.num_dofs, 3]
        link_body_lin_vel = link_body_lin_vel_flat.view(self.num_envs, 22, 3) # Reshape back to [self.num_envs, self.num_dofs, 3]
        link_relative_lin_vel = link_body_lin_vel - self.base_lin_vel.unsqueeze(1)  # [self.num_envs, self.num_dofs, 3]

        link_ang_vel = self.rigid_state[:, 1:, 10:13]  # [self.num_envs, self.num_dofs, 3]
        link_ang_vel_flat = link_ang_vel.reshape(-1, 3)  # [self.num_envs*self.num_dofs, 3]
        link_body_ang_vel_flat = quat_rotate_inverse(base_quat_flat, link_ang_vel_flat)  # [self.num_envs*self.num_dofs, 3]
        link_body_ang_vel = link_body_ang_vel_flat.view(self.num_envs, 22, 3)  # Reshape back to [self.num_envs, self.num_dofs, 3]
        link_relative_ang_vel = link_body_ang_vel - self.base_ang_vel.unsqueeze(1)  # [self.num_envs, self.num_dofs, 3]

        link_inertia = self.dof_inertia.unsqueeze(0)  # [1, self.num_dofs, 3]
        link_mass = self.link_mass.unsqueeze(0).unsqueeze(2)  # [1, self.num_dofs, 1]
        link_angular_momentum = torch.cross(link_relative_pos,(link_mass*link_relative_lin_vel)) + link_inertia * link_relative_ang_vel # [self.num_envs, self.num_dofs, 3]
        sum_angular_momentum = torch.sum(link_angular_momentum, dim=1)  # [self.num_envs, 3]
        self.angular_momentum = sum_angular_momentum.clone()  # Store angular momentum for later use
        rew = torch.square(sum_angular_momentum[:, 2])  # Only consider z-component of angular momentum
        return rew
    
    def _reward_stand_still_without_cmd(self):
        standing_mask = self.commands[:, 4] > 0.5
        diff = self.dof_pos - self.default_dof_pos
        weight = torch.tensor([1, 10, 10, 1, 1, 10] * 2 + [1, 1, 1, 1] * 2, device=self.device)
        reward = torch.sum(torch.abs(diff*weight), dim=-1)
        reward *= standing_mask.float()
        reward[self.is_pushing] = 0.0  # No reward if the robot is being pushed
        return reward
    
    def _reward_cost_of_transport(self):
        power = torch.sum(torch.abs(self.torques*self.dof_vel), dim=1) 
        weight = 28.8 * 9.81 # Approximate weight of the robot in Newtons
        velocity = torch.norm(self.commands[:, :3], dim=1) # commanded velocity
        CoT = power / (weight * velocity + 1e-6)  # Avoid division by zero
        return CoT.clip(0, 10.0)
            
    def _reward_base_height(self):
        """
        Computes the reward based on the height of the robot's base. This encourages the robot to maintain
        a stable height.
        """
        contact = self.contact_forces[:, self.feet_indices, 2] > 20.0
        measured_heights = torch.sum(
            self.rigid_state[:, self.feet_indices, 2] * contact, dim=1) / torch.sum(contact, dim=1) - self.cfg.rewards.foot_height
        measured_heights[torch.isnan(measured_heights)] = 0
        self.base_height = self.root_states[:, 2] - measured_heights
        rew = torch.exp(-self.cfg.rewards.height_sigma*torch.square(self.base_height - self.cfg.rewards.base_height_target))
        return rew

    def _reward_feet_position(self):
        """
        Calculates the reward based on the distance between the feet. Penalize feet get close to each other or too far away.
        """
        foot_pos = self.rigid_state[:, self.feet_indices, :2]
        foot_dist = torch.norm(foot_pos[:, 0, :] - foot_pos[:, 1, :], dim=1)
        fd = self.cfg.rewards.min_dist
        max_df = self.cfg.rewards.max_dist
        d_min = torch.clamp(foot_dist - fd, -0.5, 0.)
        d_max = torch.clamp(foot_dist - max_df, 0, 0.5)
        rew = torch.exp(-torch.abs(d_min) * 100) + torch.exp(-torch.abs(d_max) * 100) / 2
        
        return rew
    
    def _reward_feet_clearance(self):
        """
        Calculates reward based on the clearance of the swing leg from the ground during movement.
        Encourages appropriate lift of the feet during the swing phase of the gait.
        """
        standing_mask = self.commands[:, 4] > 0.5
        contact = self.contact_forces[:, self.feet_indices, 2] > 20.
        not_in_contact = ~contact
        
        # Get the z-position of the feet and compute the change in z-position
        self.feet_z = self.rigid_state[:, self.feet_indices, 2] - self.cfg.rewards.foot_height

        clearance_reward = torch.exp(-self.cfg.rewards.feet_clearance_sigma*torch.square(self.feet_z - self.cfg.rewards.target_feet_height))
        clearance_reward = clearance_reward * not_in_contact
        
        return torch.where(standing_mask, torch.zeros_like(clearance_reward.sum(dim=1)), clearance_reward.sum(dim=1))

    def _reward_torques(self):
        """
        Penalizes the use of high torques in the robot's joints. Encourages efficient movement by minimizing
        the necessary force exerted by the motors.
        """
        weight = torch.tensor([0.2, 1, 1, 1.5, 5, 10] * 2 + [0.5, 1, 1, 0.5] * 2, device=self.device)
        rew = torch.sum(torch.square(self.torques * weight), dim=1)
        return rew
    
    def _reward_dof_vel(self):
        """
        Penalizes high velocities at the degrees of freedom (DOF) of the robot. This encourages smoother and
        more controlled movements.
        """
        weight = torch.tensor([0.2, 1, 1, 1, 1, 1] * 2 + [0.5, 1, 1, 0.5] * 2, device=self.device)
        rew = torch.sum(torch.square(self.dof_vel * weight), dim=1)
        return rew
    
    def _reward_dof_acc(self):
        """
        Penalizes high accelerations at the robot's degrees of freedom (DOF). This is important for ensuring
        smooth and stable motion, reducing wear on the robot's mechanical parts.
        """
        rew = torch.sum(torch.square((self.last_dof_vel - self.dof_vel) / self.dt), dim=1)
        return rew
    
    def _reward_action_smoothness(self):
        """
        Encourages smoothness in the robot's actions by penalizing large differences between consecutive actions.
        This is important for achieving fluid motion and reducing mechanical stress.
        """
        term_1 = torch.sum(torch.square((self.last_actions - self.actions)), dim=1)
        term_2 = torch.sum(torch.square((self.actions + self.last_last_actions - 2 * self.last_actions)), dim=1)
        term_3 = 0.05 * torch.sum(torch.abs(self.actions), dim=1)
        rew = term_1 + term_2 + term_3
        return rew

    def _reward_base_acc(self):
        """
        Computes the reward based on the base's acceleration. Penalizes high accelerations of the robot's base,
        encouraging smoother motion. 
        - For linear acceleration: x,y,z directions (using norm)
        - For angular acceleration: roll,pitch,yaw directions (using norm)
        When x,y linear commands or yaw angular command is zero, their corresponding acceleration penalties 
        will be 10 times larger.
        """        
        root_acc = self.last_root_vel - self.root_states[:, 7:13]
        rew = torch.exp(-torch.norm(root_acc, dim=1) * 3)
        return rew

    def _reward_collision(self):
        """
        Penalizes collisions of the robot with the environment, specifically focusing on selected body parts.
        This encourages the robot to avoid undesired contact with objects or surfaces.
        """
        return torch.sum(1. * (torch.norm(self.contact_forces[:, self.penalised_contact_indices, :], dim=-1) > 0.1),dim=1)
    
    def _reward_foot_slip(self):
        """
        Calculates the reward for minimizing foot slip. The reward is based on the contact forces
        and the speed of the feet. A contact threshold is used to determine if the foot is in contact
        with the ground. The speed of the foot is calculated and scaled by the contact condition.
        """
        contact = self.contact_forces[:, self.feet_indices, 2] > 20.
        foot_speed_norm = torch.norm(self.rigid_state[:, self.feet_indices, 7:9], dim=2)
        rew = torch.sqrt(foot_speed_norm)
        rew *= contact
        return torch.sum(rew, dim=1)

    def _reward_feet_contact_forces(self):
        """
        Calculates the reward for keeping contact forces within a specified range. Penalizes
        high contact forces on the feet.
        """
        return torch.sum((torch.norm(self.contact_forces[:, self.feet_indices, :], dim=-1) - self.cfg.rewards.max_contact_force).clip(min=0.), dim=1)