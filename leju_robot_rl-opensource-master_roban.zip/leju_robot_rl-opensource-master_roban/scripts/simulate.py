import time
from os import path
from collections import defaultdict
import math

import mujoco
import mujoco.viewer
import numpy as np
import torch
from torch import nn
from scipy.spatial.transform import Rotation as R
import matplotlib.pyplot as plt
from pytorch3d.transforms import euler_angles_to_matrix, matrix_to_euler_angles

def simulate():
    # assert robot_version in XML_PATH_DICT
    model = mujoco.MjModel.from_xml_path('resources/robots/roban_s21/mjcf/biped_s13.xml')
    data = mujoco.MjData(model)
    left_foot_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "leg_l6_link")
    right_foot_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "leg_r6_link")
    left_knee_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "leg_l4_link")
    right_knee_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "leg_r4_link")
    base_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "base_link")
    time_data = []
    left_z_data = []
    right_z_data = []
    left_knee_z_data = []
    right_knee_z_data = []

    dof_num = 20

    draw_val_dict = defaultdict(list)

    idx = 0
    period = 100
    print(period)
    x, y, yaw = 0, 0, 0

    def joint_pos_remap_left(joint_pos_in):
        """
        将正交坐标系下的欧拉角转换为斜交坐标系下的关节角度
        
        Args:
            joint_pos_in: numpy array [pitch, roll, yaw]
        
        Returns:
            numpy array 包含转换后的关节角度
        """
        # 提取输入的 pitch, roll, yaw
        pitch = joint_pos_in[0]
        roll = joint_pos_in[1]
        yaw = joint_pos_in[2]

        # 将欧拉角转换为旋转矩阵（顺序为 YXZ）
        R_y = np.array([
            [np.cos(pitch), 0, np.sin(pitch)],
            [0, 1, 0],
            [-np.sin(pitch), 0, np.cos(pitch)]
        ])
        
        R_x = np.array([
            [1, 0, 0],
            [0, np.cos(roll), -np.sin(roll)],
            [0, np.sin(roll), np.cos(roll)]
        ])
        
        R_z = np.array([
            [np.cos(yaw), -np.sin(yaw), 0],
            [np.sin(yaw), np.cos(yaw), 0],
            [0, 0, 1]
        ])
        
        R_wt = R_y @ R_x @ R_z

        # 定义基坐标系到世界坐标系的旋转矩阵（绕 x 轴旋转 -45 度）
        angle_x = np.pi / 4
        R_wb = np.array([
            [1, 0, 0],
            [0, np.cos(angle_x), -np.sin(angle_x)],
            [0, np.sin(angle_x), np.cos(angle_x)]
        ])

        # 绕X轴旋转-90度的矩阵
        R_x_90 = np.array([
            [1, 0, 0],
            [0, np.cos(-np.pi/2), -np.sin(-np.pi/2)],
            [0, np.sin(-np.pi/2), np.cos(-np.pi/2)]
        ])

        # 计算基坐标系到目标坐标系的旋转矩阵
        R_bt = R_wb @ R_wt @ R_x_90

        # 将旋转矩阵分解为YXY欧拉角
        # 参考: https://www.geometrictools.com/Documentation/EulerAngles.pdf
        if abs(R_bt[1,1]) < 1e-6:
            x_angle = np.pi/2 if R_bt[1,2] > 0 else -np.pi/2
            y1_angle = np.arctan2(R_bt[0,1], R_bt[2,1])
            y2_angle = 0
        else:
            y1_angle = np.arctan2(R_bt[0,1], -R_bt[2,1])
            x_angle = np.arccos(R_bt[1,1])
            y2_angle = np.arctan2(R_bt[1,0], R_bt[1,2])

        # 调整欧拉角
        euler_angles = np.array([
            y1_angle - np.pi,           # Y轴角度调整
            -x_angle + np.pi/4,         # X轴角度调整
            -y2_angle - np.pi           # Y轴角度调整
        ])

        return euler_angles
    def analytical_ik(pitch, roll, yaw):
        
        R_wt = R.from_euler('YXZ', [pitch, roll, yaw]).as_matrix()
        # 定义基坐标系到世界坐标系的旋转矩阵（绕 x 轴旋转 -45 度）
        R_wb = R.from_euler('x', 45, degrees=True).as_matrix()
        
        # 计算基坐标系到目标坐标系的旋转矩阵
        R_bt = R_wb @ R_wt @ R.from_euler('x', -90, degrees=True).as_matrix()
        
        # 将旋转矩阵分解为欧拉角（顺序为 YXY）
        r = R.from_matrix(R_bt).as_euler("YXY")
        
        # 调整欧拉角（合并调整步骤）
        r = np.array([r[0] - np.pi, -r[1] + np.pi / 4, -r[2] - np.pi])
        r = [np.unwrap([0., ri])[1] for ri in r] # wrap to pi
        
        return r 
    def analytical_ik_right_leg(pitch, roll, yaw):
        """
        右腿模型的解析逆运动学方法。
        
        参数:
            R_wt (numpy.ndarray): 目标姿态的旋转矩阵（3x3）。
        
        返回:
            numpy.ndarray: 关节角度 [q1, q2, q3]。
        """
        R_wt = R.from_euler('YXZ', [pitch, roll, yaw]).as_matrix()
        # 定义基坐标系到世界坐标系的旋转矩阵（绕 x 轴旋转 -45 度）
        R_wb = R.from_euler('x', -45, degrees=True).as_matrix()
        
        # 计算基坐标系到目标坐标系的旋转矩阵
        R_bt = R_wb @ R_wt @ R.from_euler('x', 90, degrees=True).as_matrix()
        
        # 将旋转矩阵分解为欧拉角（顺序为 YXY）
        r = R.from_matrix(R_bt).as_euler("YXY")
        
        # 调整欧拉角（合并调整步骤）
        r = np.array([-r[0], r[1] - np.pi / 4, r[2]])
        r = [np.unwrap([0., ri])[1] for ri in r] # wrap to pi

        
        return r
    
    def analytical_fk_left_leg(motor_angles):
        """从电机空间转换到关节空间(左腿)
        
        Args:
            motor_angles: 电机角度 [batch_size, 3]
        
        Returns:
            joint_angles: 关节角度 [batch_size, 3] 
        """
        device = motor_angles.device
        dtype = motor_angles.dtype
        
        # 首先反向应用系数和偏移
        coeffs = torch.tensor([1.0, -1.0, -1.0], device=device, dtype=dtype)
        offsets = torch.tensor([-torch.pi, torch.pi/4, -torch.pi], device=device, dtype=dtype)
        
        # 反向计算YXY欧拉角
        r = motor_angles.clone()
        r = torch.atan2(torch.sin(r), torch.cos(r))  # 标准化角度
        r = (r - offsets) / coeffs
        
        # 从YXY欧拉角转换到旋转矩阵
        R_bt = euler_angles_to_matrix(r, "YXY") 
        
        # 反向应用末端和基座变换
        R_wb = euler_angles_to_matrix(
            torch.tensor([torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_end = euler_angles_to_matrix(
            torch.tensor([-torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        
        # 求解目标旋转矩阵
        R_wt = R_wb.inverse() @ R_bt @ R_end.inverse()
        
        # 转换到YXZ欧拉角
        joint_angles = matrix_to_euler_angles(R_wt, "YXZ")
        
        return joint_angles

    def analytical_fk_right_leg(motor_angles):
        """从电机空间转换到关节空间(右腿)
        
        Args:
            motor_angles: 电机角度 [batch_size, 3]
            
        Returns:
            joint_angles: 关节角度 [batch_size, 3]
        """
        device = motor_angles.device
        dtype = motor_angles.dtype
        
        # 首先反向应用系数和偏移
        coeffs = torch.tensor([-1.0, 1.0, 1.0], device=device, dtype=dtype)
        offsets = torch.tensor([0, -torch.pi/4, 0], device=device, dtype=dtype)
        
        # 反向计算YXY欧拉角
        r = motor_angles.clone()
        r = torch.atan2(torch.sin(r), torch.cos(r))  # 标准化角度
        r = (r - offsets) / coeffs
        
        # 从YXY欧拉角转换到旋转矩阵
        R_bt = euler_angles_to_matrix(r, "YXY")
        
        # 反向应用末端和基座变换
        R_wb = euler_angles_to_matrix(
            torch.tensor([-torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        R_end = euler_angles_to_matrix(
            torch.tensor([torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
            "XYZ"
        )
        
        # 求解目标旋转矩阵
        R_wt = R_wb.inverse() @ R_bt @ R_end.inverse()
        
        # 转换到YXZ欧拉角
        joint_angles = matrix_to_euler_angles(R_wt, "YXZ")
        
        return joint_angles

    
    def get_odf_pos():
        x = 0 # (idx % period) / period * 2 * math.pi
        scale_1 = 0.3 * 2
        scale_2 = 2 * scale_1
        scale_3 = 0.5 * scale_1
        double_stance_phase = 0.3
        pos = np.sin(x)
        pos = np.where(abs(pos) < double_stance_phase, 0, pos)
        pos = np.where(pos > 0, pos - double_stance_phase, pos)
        pos = np.where(pos < 0, pos + double_stance_phase, pos)
        pos_ = max(pos, 0)
        pos_right = - pos
        pos_right_ = max(pos_right, 0)
        joint_pos_in = np.array([-pos_ * scale_1 - 0.3, 0, 0])
        joint_pos_in_right = np.array([-pos_right_ * scale_1 - 0.3, 0, 0])
        joint_pos_out = analytical_ik(joint_pos_in[0], joint_pos_in[1], joint_pos_in[2])
        joint_pos_out_right = analytical_ik_right_leg(joint_pos_in_right[0], joint_pos_in_right[1], joint_pos_in_right[2])
        joint_test = torch.from_numpy(np.array(joint_pos_out)).float()
        joint_test_right = torch.from_numpy(np.array(joint_pos_out_right)).float()
        joint_pos_out_test = analytical_fk_left_leg(joint_test)
        print("joint_pos_in:",joint_pos_in)
        print("joint_pos_out", joint_pos_out)
        joint_pos_out_test_right = analytical_fk_right_leg(joint_test_right)
        print("joint_pos_in_right:",joint_pos_in_right)
        print("joint_pos_out_right", joint_pos_out_right)

        dos_pos = np.zeros(dof_num)
        dos_pos[0] = 0#joint_pos_out[0]
        dos_pos[1] = 0#joint_pos_out[1]
        dos_pos[2] = 0#joint_pos_out[2]
        dos_pos[3] = 0.1#pos_ * scale_2 + 0.5
        print("dos_pos", dos_pos[3])
        print("pos", pos <= 0 )
        dos_pos[4] = 0#- pos_ * scale_1 / 2.5 - 0.2
        dos_pos[6] = 0#joint_pos_out_right[0]
        dos_pos[7] = 0#joint_pos_out_right[1]
        dos_pos[8] = 0#joint_pos_out_right[2]
        dos_pos[9] = 0.1#pos_right_ * scale_2 + 0.5
        dos_pos[10] = 0#- pos_right_ * scale_1 / 2.5 - 0.2
        arm_pos = -np.sin(x)  # 使用原始正弦波，不加双足支撑处理
        arm_pos_ = max(arm_pos, 0)
        arm_pos_right = -arm_pos
        arm_pos_right_ = max(arm_pos_right, 0)
        dos_pos[12] = -arm_pos * scale_3
        dos_pos[15] = -arm_pos_ * scale_1
        dos_pos[16] = -arm_pos_right * scale_3
        dos_pos[19] = -arm_pos_right_ * scale_1
        euler_xy = np.zeros(2)
        height = 0.68
        lin_vel = np.zeros(3)
        ang_vel = np.zeros(3)

        return dos_pos, euler_xy, height, lin_vel, ang_vel

    with mujoco.viewer.launch_passive(model, data) as viewer:
        while viewer.is_running():
            # 获取左右脚位置
            time_data.append(data.time)
            left_z_data.append(data.xpos[left_foot_id][2])
            right_z_data.append(data.xpos[right_foot_id][2])
            left_knee_z_data.append(data.xpos[left_knee_id][2])
            right_knee_z_data.append(data.xpos[right_knee_id][2])
            height = data.xpos[base_id][2]
            print("height:", height)
            step_start = time.time()
            dos_pos, euler_xy, height, lin_vel, ang_vel = get_odf_pos()
            # print(ang_vel[2])

            rot = R.from_euler("xyz",[euler_xy[0], euler_xy[1], yaw])
            global_lin_vel = rot.apply(lin_vel)
            x += global_lin_vel[0] * 0.01
            y += global_lin_vel[1] * 0.01
            yaw += ang_vel[2] * 0.01

            data.qpos[0] = x
            data.qpos[1] = y
            data.qpos[2] = height
            data.qpos[3:7] = rot.as_quat()[[3, 0, 1, 2]]
            data.qpos[7:7 + dof_num] = dos_pos

            data.qvel[:] = 0
            mujoco.mj_step(model, data, 10)

            draw_val_dict["qpos"].append(data.qpos.copy())
            draw_val_dict["qvel"].append(data.qvel.copy())
            draw_val_dict["xpos"].append(data.xpos.copy())

            viewer.sync()

            time_until_next_step = 0.01 - (time.time() - step_start)
            if time_until_next_step > 0:
                time.sleep(time_until_next_step)

            idx += 1
    left_knee_diff = np.array(left_knee_z_data) - np.array(left_z_data)
    right_knee_diff = np.array(right_knee_z_data) - np.array(right_z_data)
    plt.figure(figsize=(10, 6))
    plt.plot(time_data, left_z_data, 'b-', label='left foot')
    plt.plot(time_data, right_z_data, 'r-', label='right foot')
    plt.plot(time_data, left_knee_z_data, 'g-', label='left knee')
    plt.plot(time_data, right_knee_z_data, 'y-', label='right knee')
    plt.plot(time_data, left_knee_diff, 'c-', label='left knee diff')
    plt.plot(time_data, right_knee_diff, 'm-', label='right knee diff')

    plt.xlabel('time (s)')
    plt.ylabel('Z position (m)')
    plt.title('end-effector Z position over time')
    plt.grid(True)
    plt.legend()
    plt.show()
    #
    # qpos = np.array(draw_val_dict["qpos"])
    # qvel = np.array(draw_val_dict["qvel"])
    # xpos = np.array(draw_val_dict["xpos"])
    # for i in [0, 6]:
    #     plt.plot(qpos[:, 7 + i], label=f"qpos {i}")
    # # plt.plot(-qpos[:-period // 2, 7 + 1], label=f"qpos {0}")
    # # plt.plot(qpos[period // 2:, 7 + 7], label=f"qpos {6}")
    # # plt.plot(qpos[:, 7 + 10], label=f"qpos {4}")
    # # plt.plot(-np.cos(np.arange(idx) / period * 2 * math.pi), label=f"qpos {4}")
    # # plt.plot(qpos[7 + 3], label=f"qpos {4}")
    # plt.legend()
    # plt.show()
    #
    #


if __name__ == '__main__':
    simulate()
