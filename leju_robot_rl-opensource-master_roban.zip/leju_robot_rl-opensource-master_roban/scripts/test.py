from pytorch3d.transforms import euler_angles_to_matrix, matrix_to_euler_angles
import torch
import numpy as np
from scipy.spatial.transform import Rotation as R

def analytical_fk_left_leg(motor_angles):
    """从电机空间转换到关节空间(左腿)
    
    Args:
        motor_angles: 电机角度 [batch_size, 3]
    
    Returns:
        joint_angles: 关节角度 [batch_size, 3] 
    """
    device = motor_angles.device
    dtype = motor_angles.dtype
    
    # 首先反向应用系数和偏移
    coeffs = torch.tensor([1.0, -1.0, -1.0], device=device, dtype=dtype)
    offsets = torch.tensor([-torch.pi, torch.pi/4, -torch.pi], device=device, dtype=dtype)
    
    # 反向计算YXY欧拉角
    r = motor_angles.clone()
    r = torch.atan2(torch.sin(r), torch.cos(r))  # 标准化角度
    r = (r - offsets) / coeffs
    
    # 从YXY欧拉角转换到旋转矩阵
    R_bt = euler_angles_to_matrix(r, "YXY") 
    
    # 反向应用末端和基座变换
    R_wb = euler_angles_to_matrix(
        torch.tensor([torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    R_end = euler_angles_to_matrix(
        torch.tensor([-torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    
    # 求解目标旋转矩阵
    R_wt = R_wb.inverse() @ R_bt @ R_end.inverse()
    
    # 转换到YXZ欧拉角
    joint_angles = matrix_to_euler_angles(R_wt, "YXZ")
    
    return joint_angles

def analytical_fk_right_leg(motor_angles):
    """从电机空间转换到关节空间(右腿)
    
    Args:
        motor_angles: 电机角度 [batch_size, 3]
        
    Returns:
        joint_angles: 关节角度 [batch_size, 3]
    """
    device = motor_angles.device
    dtype = motor_angles.dtype
    
    # 首先反向应用系数和偏移
    coeffs = torch.tensor([-1.0, 1.0, 1.0], device=device, dtype=dtype)
    offsets = torch.tensor([0, -torch.pi/4, 0], device=device, dtype=dtype)
    
    # 反向计算YXY欧拉角
    r = motor_angles.clone()
    r = torch.atan2(torch.sin(r), torch.cos(r))  # 标准化角度
    r = (r - offsets) / coeffs
    
    # 从YXY欧拉角转换到旋转矩阵
    R_bt = euler_angles_to_matrix(r, "YXY")
    
    # 反向应用末端和基座变换
    R_wb = euler_angles_to_matrix(
        torch.tensor([-torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    R_end = euler_angles_to_matrix(
        torch.tensor([torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    
    # 求解目标旋转矩阵
    R_wt = R_wb.inverse() @ R_bt @ R_end.inverse()
    
    # 转换到YXZ欧拉角
    joint_angles = matrix_to_euler_angles(R_wt, "YXZ")
    
    return joint_angles


def analytical_ik_left_leg(pitch, roll, yaw):

    R_wt = R.from_euler('YXZ', [pitch, roll, yaw]).as_matrix()
    # 定义基坐标系到世界坐标系的旋转矩阵（绕 x 轴旋转 -45 度）
    R_wb = R.from_euler('x', 45, degrees=True).as_matrix()

    # 计算基坐标系到目标坐标系的旋转矩阵
    R_bt = R_wb @ R_wt @ R.from_euler('x', -90, degrees=True).as_matrix()

    # 将旋转矩阵分解为欧拉角（顺序为 YXY）
    r = R.from_matrix(R_bt).as_euler("YXY")

    # 调整欧拉角（合并调整步骤）
    r = np.array([r[0] - np.pi, -r[1] + np.pi / 4, -r[2] - np.pi])
    r = [np.unwrap([0., ri])[1] for ri in r]  # wrap to pi

    return r


def analytical_ik_right_leg(pitch, roll, yaw):
    """
    右腿模型的解析逆运动学方法。

    参数:
        R_wt (numpy.ndarray): 目标姿态的旋转矩阵（3x3）。

    返回:
        numpy.ndarray: 关节角度 [q1, q2, q3]。
    """
    R_wt = R.from_euler('YXZ', [pitch, roll, yaw]).as_matrix()
    # 定义基坐标系到世界坐标系的旋转矩阵（绕 x 轴旋转 -45 度）
    R_wb = R.from_euler('x', -45, degrees=True).as_matrix()

    # 计算基坐标系到目标坐标系的旋转矩阵
    R_bt = R_wb @ R_wt @ R.from_euler('x', 90, degrees=True).as_matrix()

    # 将旋转矩阵分解为欧拉角（顺序为 YXY）
    r = R.from_matrix(R_bt).as_euler("YXY")

    # 调整欧拉角（合并调整步骤）
    r = np.array([-r[0], r[1] - np.pi / 4, r[2]])
    r = [np.unwrap([0., ri])[1] for ri in r]  # wrap to pi

    return r


def analytical_ik_torch(euler_angles):
    device = euler_angles.device
    dtype = euler_angles.dtype
    R_wt = euler_angles_to_matrix(euler_angles, "YXZ")
    R_wb = euler_angles_to_matrix(
        torch.tensor([torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    R_end = euler_angles_to_matrix(
        torch.tensor([-torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    R_bt = R_wb @ R_wt @ R_end

    r = matrix_to_euler_angles(R_bt, "YXY")
    coeffs = torch.tensor([1.0, -1.0, -1.0], device=device, dtype=dtype)
    offsets = torch.tensor(
        [-torch.pi, torch.pi/4, -torch.pi], device=device, dtype=dtype)
    r = r * coeffs + offsets
    r = torch.atan2(torch.sin(r), torch.cos(r))
    return r


def analytical_ik_right_leg_torch(euler_angles):
    device = euler_angles.device
    dtype = euler_angles.dtype
    R_wt = euler_angles_to_matrix(euler_angles, "YXZ")
    R_wb = euler_angles_to_matrix(
        torch.tensor([-torch.pi/4, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    R_end = euler_angles_to_matrix(
        torch.tensor([torch.pi/2, 0.0, 0.0], device=device, dtype=dtype),
        "XYZ"
    )
    R_bt = R_wb @ R_wt @ R_end

    r = matrix_to_euler_angles(R_bt, "YXY")
    coeffs = torch.tensor([-1.0, 1.0, 1.0], device=device, dtype=dtype)
    offsets = torch.tensor(
        [0, -torch.pi/4, 0], device=device, dtype=dtype)
    r = r * coeffs + offsets
    r = torch.atan2(torch.sin(r), torch.cos(r))
    return r


# 测试代码
batch_size = 10
euler_angles = np.random.random([batch_size, 3])
motor_angles = np.zeros([batch_size, 3])
motor_angles_right = np.zeros([batch_size, 3])

pitch = euler_angles[:, 0]
roll = euler_angles[:, 1]
yaw = euler_angles[:, 2]

# 计算逆运动学得到电机角度
for i in range(batch_size):
    motor_angles[i, :] = analytical_ik_left_leg(pitch[i], roll[i], yaw[i])
    motor_angles_right[i, :] = analytical_ik_right_leg(pitch[i], roll[i], yaw[i])

# 转换为tensor进行正运动学计算
motor_angles_tensor = torch.from_numpy(motor_angles).float()
motor_angles_right_tensor = torch.from_numpy(motor_angles_right).float()

# 通过正运动学计算得到欧拉角
euler_angles_fk = analytical_fk_left_leg(motor_angles_tensor)
euler_angles_right_fk = analytical_fk_right_leg(motor_angles_right_tensor)

# 计算原始欧拉角和正运动学计算得到的欧拉角之间的误差
euler_angles_tensor = torch.from_numpy(euler_angles).float()
print("原始欧拉角：",euler_angles_tensor)
print("左腿正运动学计算得到的欧拉角：",euler_angles_fk)
print("右腿正运动学计算得到的欧拉角：",euler_angles_right_fk)
err_left = torch.abs(euler_angles_tensor - euler_angles_fk).sum()
err_right = torch.abs(euler_angles_tensor - euler_angles_right_fk).sum()

print("左腿正逆运动学误差:", err_left.item())
print("右腿正逆运动学误差:", err_right.item())
