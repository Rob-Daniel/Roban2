import argparse
import numpy as np
import mujoco
import time
from scipy.spatial.transform import Rotation
from play_mujoco import PlayMujoco 

PUSH_DIRECTIONS = [(1, 0), (-1, 0), (0, 1), (0, -1)]  # +X, –X, +Y, –Y
START_FORCE_N   =  20.0           # first push magnitude [N]
FORCE_STEP_N    =  10.0           # increment each round [N]
MAX_FORCE_N     = 1000.0         # stop if still standing at this [N]
DELAY_BEFORE_PUSH = 2.0          # wait before applying force [seconds]
IMPULSE_TIME    = 0.5            # how long to apply force [seconds]
EPISODE_LEN     = 5.0            # allow recovery time [seconds]
FAIL_HEIGHT     = 0.45           # height threshold for failure [m]
FAIL_ANGLE_RAD  = np.deg2rad(45) # tilt threshold for failure [radians]

def has_fallen(data, model) -> bool:
    base_link_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "base_link")
    height = data.xpos[base_link_id, 2]
    quat = data.xquat[base_link_id, [1,2,3,0]]
    r = Rotation.from_quat(quat)
    euler = r.as_euler('xyz', degrees=False)          # roll, pitch, yaw
    tilt  = max(abs(euler[0]), abs(euler[1]))        # roll or pitch
    return (height < FAIL_HEIGHT) or (tilt > FAIL_ANGLE_RAD)

def run_push_test(policy_path, robot_version="s2"):
    tester = PlayMujoco(policy_path, robot_version=robot_version)
    model, data = tester.model, tester.data
    root_body   = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "base_link")
    tester.vel_x, tester.vel_y, tester.vel_yaw, tester.standing = 0, 0, 0, 0
    results = {}   # {(dx,dy):  lowest-failure-N}
    with mujoco.viewer.launch_passive(model, data) as viewer:
        viewer.cam.type        = mujoco.mjtCamera.mjCAMERA_TRACKING
        viewer.cam.trackbodyid = root_body
        viewer.cam.distance    = 2.0      # zoom-out
        viewer.cam.elevation   = -15      # look slightly down
        viewer.cam.azimuth     = 180      # look from −X

        for dx, dy in PUSH_DIRECTIONS:
            force_Ns = START_FORCE_N
            failed = False
            print(f"\n=== Direction ({dx:+}, {dy:+}) ===")
            while force_Ns <= MAX_FORCE_N and not failed:
                mujoco.mj_resetData(model, data)
                mujoco.mj_forward(model, data)          # recompute derived
                tester.reset_buffers()                  # clear obs history, timers
                tester.time_s = 0.0
                push_step_left = IMPULSE_TIME / model.opt.timestep

                while tester.time_s < EPISODE_LEN:
                    start_time = time.time()
                    tester.act()
                    
                    for _ in range(tester.control_freq):
                        if tester.time_s < DELAY_BEFORE_PUSH or push_step_left <= 0:
                            # wait before applying force or impulse finished
                            data.xfrc_applied[root_body, :2] = 0
                        else:
                            fx = dx * force_Ns # force in X direction
                            fy = dy * force_Ns # force in Y direction
                            data.xfrc_applied[root_body, 0] = fx # apply force in X direction
                            data.xfrc_applied[root_body, 1] = fy # apply force in Y direction
                            push_step_left -= 1 # decrement remaining steps for impulse
                            
                        tester.apply_pd_torque_once()     # one PD + mj_step
                        tester.time_s += model.opt.timestep

                    if has_fallen(data, model):
                        failed = True
                        break
                    if viewer.is_running():
                        viewer.sync()
                    
                    end_time = time.time()
                    time.sleep(max(0, 0.01 - (end_time - start_time)))

                status = "FAIL" if failed else "OK"
                print(f"  {force_Ns:4.0f} N for {IMPULSE_TIME} s -> {status}")
                if failed:
                    results[(dx,dy)] = force_Ns - FORCE_STEP_N
                force_Ns += FORCE_STEP_N

    print("\n========== RESULTS ==========")
    result_lines = []
    for (dx,dy), force in results.items():
        direction = "X+" if (dx,dy)==(1,0) else "X-" if (dx,dy)==(-1,0) \
                    else "Y+" if (dx,dy)==(0,1) else "Y-"
        line = f"{direction}: maximum disturbance force tolerated is {force} N for {IMPULSE_TIME} s"
        print(line)
        result_lines.append(line)
    result_filename = f"push_test_results.txt"
    with open(result_filename, "a") as f:
        f.write("\n========================================================================================================\n")
        f.write(f"Model: {policy_path}\n")
        f.write(f"Test Time: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        for line in result_lines:
            f.write(line + "\n")
        f.write("========================================================================================================\n")
    print(f"\nResults saved to {result_filename}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("onnx_path", type=str)
    args = ap.parse_args()
    run_push_test(args.onnx_path)