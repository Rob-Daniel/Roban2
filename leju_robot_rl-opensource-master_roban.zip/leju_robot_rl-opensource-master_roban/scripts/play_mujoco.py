import argparse
from os import path
from collections import deque
import time
import curses
from functools import partial
import math

import numpy as np
import mujoco
import mujoco.viewer
import onnxruntime
from scipy.spatial.transform import Rotation
import matplotlib.pyplot as plt

PLOT_CONTACT_FORCES = True
PLOT_BODY_VELOCITIES = True
PLOT_JOINT_TORQUES = True
PLOT_STEP_PERIODS = False
PLOT_STEP_LENGTHS = True

BASE_PATH = path.dirname(path.dirname(path.dirname(__file__)))

DEFAULT_PARAMS_DICT = {
    "s2": {
        "p_gains": [100., 100., 100., 150., 40., 40.] * 2 + [15] * 8,
        "d_gains": [2.0, 2.0, 2.0, 4.0, 4.0, 2.0] * 2 + [3] * 8,
        "default_height": 0.67,
        "default_dof_pos":[-0.412, -0.0437, -0.287, 0.5, -0.2, 0.0] + [0.412, 0.0437, 0.287, 0.5, -0.2, -0.0] + [0.3, 0.1, 0, -0.6] + [0.3, -0.1, 0, -0.6] ,
        "default_pitch": 0.00,
        "period_length": 1.0,
        "mjcf": path.join(BASE_PATH, "resources", "robots", "roban_s21", "mjcf", "biped_s13.xml")
    },
}

INPUT_LIST =["command", "dof_pos", "dof_vel", "pre_action", "base_ang_vel", "base_euler_xyz", "base_lin_acc"]

class LowPassFilter2ndOrder:
    def __init__(self, dt, cutoff_freq=(20, 20, 20)):
        sample_freq = 1.0 / dt
        cutoff_freq = np.array(cutoff_freq)

        self.dim_num = cutoff_freq.shape[0]
        self._sample_freq = sample_freq
        self._cutoff_freq = cutoff_freq

        self._delay_element_1 = np.zeros(self.dim_num)
        self._delay_element_2 = np.zeros(self.dim_num)

        fr = sample_freq / cutoff_freq
        ohm = np.tan(math.pi / fr)
        c = 1.0 + 2.0 * math.cos(math.pi / 4.0) * ohm + ohm * ohm

        self._b0 = ohm * ohm / c
        self._b1 = 2.0 * self._b0
        self._b2 = self._b0

        self._a1 = 2.0 * (ohm * ohm - 1.0) / c
        self._a2 = (1.0 - 2.0 * math.cos(math.pi / 4.0) * ohm + ohm * ohm) / c

    def update(self, inputs):
        delay_element_0 = inputs - self._delay_element_1 * self._a1 - self._delay_element_2 * self._a2
        output = delay_element_0 * self._b0 + self._delay_element_1 * self._b1 + self._delay_element_2 * self._b2

        self._delay_element_2 = self._delay_element_1.copy()
        self._delay_element_1 = delay_element_0.copy()
        return output

class PlayMujoco:
    def __init__(
            self,
            onnx_path,
            frame_stack=10,
            frame_stack_skip=1,
            dof_num=20,
            control_freq=10,
            params_dict=DEFAULT_PARAMS_DICT,
            robot_version="s2",
    ):
        assert robot_version in params_dict, f"Invalid robot version: {robot_version}"
        self.params = params_dict[robot_version]

        self.onnx_path = onnx_path
        self.frame_stack = frame_stack
        self.frame_stack_skip = frame_stack_skip
        self.action_num = dof_num
        self.robot_xml_path = "/home/lejurobot/roban_gym/resources/robots/roban_s21/mjcf/biped_s13.xml"
        self.control_freq = control_freq
        self.p_gains = np.array(self.params["p_gains"])
        self.d_gains = np.array(self.params["d_gains"])
        self.default_height = self.params["default_height"]
        self.default_pitch = self.params["default_pitch"]
        self.default_dof_pos = np.array(self.params["default_dof_pos"])
        self.period_length = self.params["period_length"]
        self.input_list = INPUT_LIST
        self.lin_acc_filter = LowPassFilter2ndOrder(0.01, (10, 10, 10))

        self.input_info = {}
        for i, name in enumerate(self.input_list):
            if name == "command":
                self.input_info[name] = 4
                # self.input_info[name] = 6
            elif name in ["dof_pos", "dof_vel", "pre_action"]:
                self.input_info[name] = dof_num
            elif name == "base_euler_xyz":
                self.input_info[name] = 2
            elif name in ["base_ang_vel", "base_lin_acc"]:
                self.input_info[name] = 3
            else:
                raise ValueError(f"Invalid input name: {name}")

        self.ort_session = onnxruntime.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])

        self.obs_history = deque(maxlen=frame_stack)
        self.real_frame_stack = int(frame_stack / frame_stack_skip)
        for _ in range(frame_stack):
            self.obs_history.append(np.zeros(sum(self.input_info.values())))

        self.model = mujoco.MjModel.from_xml_path(self.robot_xml_path)
        self.torque_limit = np.abs(self.model.actuator_ctrlrange[:, 0])

        self.model.opt.timestep = 0.001
        self.data = mujoco.MjData(self.model)
        init_quat = Rotation.from_euler("xyz", [0, self.default_pitch, 0]).as_quat()
        self.data.qpos[:7] = [0., 0., self.default_height, init_quat[3], init_quat[0], init_quat[1], init_quat[2]]
        self.data.qpos[7:] = self.default_dof_pos.copy()
        self.data.qvel[:] = 0
        self.torque = np.zeros(dof_num)
        self.time_s = 0
        self.pre_action = np.zeros(dof_num)
        self.actions = np.zeros(dof_num)
        self.base_lin_acc = np.zeros(3)
        self.vel_x, self.vel_y, self.vel_yaw = 0, 0, 0
        self.vel_x_range = [-0.6, 0.6]
        self.vel_y_range = [-0.6, 0.6]
        self.vel_yaw_range = [-0.6, 0.6]
        self.standing = 1

        # Cadence related variables
        self.left_foot_id  = mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_GEOM,"left_foot")
        self.right_foot_id = mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_GEOM,"right_foot")
        self.prev_contact = [False, False]           # contact state at t-1  [L, R]
        self.prev_strike_t = None                    # time of the last strike (any foot)
        self.step_period_log = []                    # list of periods [s] between strikes
        self.last_touchdown_pos = [None, None]
        self.prev_contact_idx = -1
        self.step_lengths = []

    def update_command(self, stdscr):
        stdscr.nodelay(True)
        key = stdscr.getch()
        if key == ord('w'):
            self.standing = 0
            self.vel_x += 0.1
        elif key == ord('s'):
            self.standing = 0
            self.vel_x -= 0.1
        elif key == ord('a'):
            self.standing = 0
            self.vel_y += 0.1
        elif key == ord('d'):
            self.standing = 0
            self.vel_y -= 0.1
        elif key == ord('q'):
            self.standing = 0
            self.vel_yaw += 0.1
        elif key == ord('e'):
            self.standing = 0
            self.vel_yaw -= 0.1
        elif key == ord(' '):
            self.standing = 1
            self.vel_x, self.vel_y, self.vel_yaw = 0, 0, 0
        elif key == ord('m'):
            self.standing = 0
            self.vel_x, self.vel_y, self.vel_yaw = 0, 0, 0
        self.vel_x = np.clip(self.vel_x, *self.vel_x_range)
        self.vel_y = np.clip(self.vel_y, *self.vel_y_range)
        self.vel_yaw = np.clip(self.vel_yaw, *self.vel_yaw_range)

    def show_command(self, stdscr):
        stdscr.clear()
        period_str = f"{self.step_period_log[-1]:.2f} s" if self.step_period_log else "–"
        step_length_str = f"{self.step_lengths[-1]:.2f} m" if self.step_lengths else "–"
        stdscr.addstr(0, 0, f'Current velocity: x={self.vel_x}, y={self.vel_y}, yaw={self.vel_yaw}, ' 
                        f'step period={period_str}, step length={step_length_str}')
        stdscr.refresh()

    def act(self):
        self.obs_history.append(self.get_obs_now())

        obs_buf_all = np.stack([self.obs_history[i] for i in range(self.frame_stack)], axis=0)
        obs_buf_all = obs_buf_all.reshape(self.real_frame_stack, self.frame_stack_skip, -1).astype(np.float32)

        input_name = self.ort_session.get_inputs()[0].name
        outputs = self.ort_session.run(None, {input_name: obs_buf_all[:, -1].reshape(1, -1)})
        self.actions = outputs[0][0]
        self.actions = np.clip(self.actions, -18.0, 18.0)

    # Apply PD torque control once for test_push_disturbance.py
    def apply_pd_torque_once(self):
        p_torque = self.p_gains * (self.actions * 0.25 + self.default_dof_pos - self.data.qpos[7:])
        # motor_pos = joint_to_motor_position_np(self.data.qpos[7:])
        # motor_vel = joint_to_motor_velocity_np(self.data.qpos[7:], motor_pos, self.data.qvel[6:])
        # motor_torque = -self.d_gains * motor_vel
        # d_torque = motor_to_joint_torque_np(self.data.qpos[7:], motor_pos, motor_torque)
        d_torque = -self.d_gains * self.data.qvel[6:]
        self.torque = np.clip(p_torque + d_torque, -self.torque_limit, self.torque_limit)
        self.data.ctrl[:]  = self.torque
        self.pre_action = self.actions.copy()

        mujoco.mj_step(self.model, self.data, 1)  # 1 ms physics step

    # reset buffers for test_push_disturbance.py
    def reset_buffers(self) -> None:
        # observation history
        self.obs_history.clear()
        for _ in range(self.frame_stack):
            self.obs_history.append(np.zeros(sum(self.input_info.values())))

        # previous action / torque
        self.pre_action[:] = 0
        self.torque[:]     = 0

    @property
    def phase(self):
        if self.standing == 1:
            return 0
        else:
            return self.time_s / self.period_length if self.period_length > 0 else 0

    def get_obs_now(self):
        phase = 2 * math.pi * self.phase
        # commands = np.array([np.sin(phase), np.cos(phase), self.vel_x, self.vel_y, self.vel_yaw, self.standing])
        commands = np.array([self.vel_x, self.vel_y, self.vel_yaw, self.standing])
        dof_pos = (self.data.qpos[7:] - self.default_dof_pos)
        dof_vel = self.data.qvel[6:]

        quat = self.data.qpos[3:7][[1, 2, 3, 0]]
        r = Rotation.from_quat(quat)
        base_euler_xyz = r.as_euler("xyz")
        base_ang_vel = self.data.qvel[3:6]
        original_lin_acc = self.data.sensor("BodyAcc").data
        base_lin_acc = self.lin_acc_filter.update(original_lin_acc)

        obs_now = np.concatenate([
            commands, dof_pos, dof_vel,
            self.pre_action,
            base_ang_vel, base_euler_xyz[:2],
            base_lin_acc
        ]).copy()

        return obs_now

    @property
    def root_rot(self):
        quat = self.data.qpos[3:7][[1, 2, 3, 0]]
        return Rotation.from_quat(quat)

    def play(self, stdscr):
        curses.curs_set(0)

        dof_pos_list = []
        body_xmat_list = []
        body_xpos_list = []
        torque_list = []
        acc_list = []
        body_vel_list = []
        cmd_vel_list = []
        contact_force_list = []

        with mujoco.viewer.launch_passive(self.model, self.data) as viewer:
            while viewer.is_running():
                self.update_command(stdscr)
                self.show_command(stdscr)

                start_time = time.time()
                self.act()

                for i in range(self.control_freq):
                    p_torque = self.p_gains * (self.actions * 0.25 + self.default_dof_pos - self.data.qpos[7:])

                    # motor_pos = joint_to_motor_position_np(self.data.qpos[7:])
                    # motor_vel = joint_to_motor_velocity_np(self.data.qpos[7:], motor_pos, self.data.qvel[6:])
                    # motor_torque = - self.d_gains * motor_vel
                    # d_torque = motor_to_joint_torque_np(self.data.qpos[7:], motor_pos, motor_torque)
                    d_torque = -self.d_gains * self.data.qvel[6:]
                    self.torque = p_torque + d_torque
                    self.torque = np.clip(self.torque, -self.torque_limit, self.torque_limit)
                    self.data.ctrl[:] = self.torque

                    mujoco.mj_step(self.model, self.data, 1)

                contact_now = [False, False]                     # [L, R]
                for k in range(self.data.ncon):
                    con = self.data.contact[k]
                    if con.geom[0] in (self.left_foot_id, self.right_foot_id):
                        idx = 0 if con.geom[0] == self.left_foot_id else 1
                        contact_now[idx] = True
                    if con.geom[1] in (self.left_foot_id, self.right_foot_id):
                        idx = 0 if con.geom[1] == self.left_foot_id else 1
                        contact_now[idx] = True

                for idx in range(2):
                    if contact_now[idx] and not self.prev_contact[idx]:
                        if self.prev_strike_t is not None:
                            period = self.time_s - self.prev_strike_t   # seconds since last strike
                            self.step_period_log.append(period)
                        self.prev_strike_t = self.time_s
                self.prev_contact = contact_now

                contact_idx = -1
                if contact_now[0] and not contact_now[1]:
                    contact_idx = 0  # left foot only
                elif contact_now[1] and not contact_now[0]:
                    contact_idx = 1  # right foot only

                # Detect new touchdown (foot swap)
                if contact_idx != -1 and contact_idx != self.prev_contact_idx:
                    # Get global position of the contacting foot
                    if contact_idx == 0:
                        foot_pos = self.data.body("leg_l6_link").xpos.copy()  # [x, y, z]
                    else:
                        foot_pos = self.data.body("leg_r6_link").xpos.copy()
                    if self.last_touchdown_pos[contact_idx] is not None:
                        step_vec = foot_pos[:2] - self.last_touchdown_pos[contact_idx][:2]  # [2]
                        cmd_vel = np.array([self.vel_x, self.vel_y])
                        cmd_norm = np.linalg.norm(cmd_vel)
                        if cmd_norm > 1e-6:
                            cmd_dir = cmd_vel / cmd_norm
                            # Project step vector onto commanded direction
                            step_proj = np.dot(step_vec, cmd_dir)
                            step_proj = max(step_proj, 0.0)  # Only reward positive steps
                            step_length = step_proj * cmd_norm
                        else:
                            step_length = 0.0
                        step_length = np.linalg.norm(foot_pos[:2] - self.last_touchdown_pos[contact_idx][:2])  # 2D step length
                        self.step_lengths.append(step_length)
                    # Update last touchdown position for this foot
                    self.last_touchdown_pos[contact_idx] = foot_pos
                    self.prev_contact_idx = contact_idx
                elif contact_idx == -1:
                    self.prev_contact_idx = -1  # reset if double/no contact

                viewer.sync()

                end_time = time.time()
                time.sleep(max(0, 0.01 - (end_time - start_time)))
                self.pre_action = self.actions.copy()

                dof_pos_list.append(self.data.qpos[7:].copy())
                body_xmat_list.append(self.data.body("leg_r6_link").xmat.copy())
                body_xpos_list.append(self.data.body("leg_r6_link").xpos.copy())
                torque_list.append(self.torque.copy())
                acc_list.append(self.base_lin_acc.copy())

                lin_vel = self.root_rot.apply(self.data.qvel[:3], inverse=True)
                ang_vel = self.root_rot.apply(self.data.qvel[3:6], inverse=True)
                body_vel_list.append(np.array([lin_vel[0], lin_vel[1], ang_vel[2]]))
                cmd_vel_list.append(np.array([self.vel_x, self.vel_y, self.vel_yaw]))

                left_force = np.linalg.norm(self.data.sensor("left_force").data)
                right_force = np.linalg.norm(self.data.sensor("right_force").data)

                contact_force_list.append([left_force, right_force])
                self.time_s += 0.01

        
        if PLOT_CONTACT_FORCES:
            contact_force = np.array(contact_force_list)
            max_force = np.max(contact_force, axis=0)
            avg_force = np.mean(contact_force, axis=0)
            plt.figure()
            plt.plot(contact_force[:, 0], label="left foot force")
            plt.plot(contact_force[:, 1], label="right foot force")
            plt.legend(loc="lower left")
            plt.title("Contact Forces on Feet")
            plt.xlabel("Timestep")
            plt.ylabel("Force [N]")
            textstr = (
                f"Left foot: max={max_force[0]:.2f}N, avg={avg_force[0]:.2f}N\n"
                f"Right foot: max={max_force[1]:.2f}N, avg={avg_force[1]:.2f}N"
            )
            plt.gca().text(
                0.02, 0.98, textstr, transform=plt.gca().transAxes,
                fontsize=10, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
            plt.show()
        if PLOT_BODY_VELOCITIES:
            root_vel = np.array(body_vel_list)
            cmd_vel = np.array(cmd_vel_list)
            fig, axes = plt.subplots(1, 3, figsize=(15, 5))
            labels = ["X Velocity", "Y Velocity", "Yaw Velocity"]
            for i in range(3):
                axes[i].plot(root_vel[:, i], label="Actual")
                axes[i].plot(cmd_vel[:, i], label="Commanded", linestyle="--")
                axes[i].set_title(labels[i])
                axes[i].set_xlabel("Timestep")
                axes[i].set_ylabel("Velocity")
                axes[i].legend()
            plt.tight_layout()
            plt.show()
        if PLOT_STEP_PERIODS:
            plt.figure()
            plt.plot(np.arange(len(self.step_period_log)), self.step_period_log)
            plt.xlabel("Step index")
            plt.ylabel("Step period [s]")
            plt.title("Time Between Consecutive Foot-Strikes")
            plt.ylim(0, 1.0)  # Lock y-axis from 0 to 1.0
            plt.show()
        if PLOT_JOINT_TORQUES:
            torque = np.array(torque_list)
            fig, axes = plt.subplots(2, 3, figsize=(15, 8))
            joint_names = [
                ("Hip Pitch", 0, 6),
                ("Hip Roll", 1, 7),
                ("Hip Yaw", 2, 8),
                ("Knee Pitch", 3, 9),
                ("Ankle Pitch", 4, 10),
                ("Ankle Roll", 5, 11),
            ]
            for idx, (title, l_idx, r_idx) in enumerate(joint_names):
                ax = axes[idx // 3, idx % 3]
                ax.plot(torque[:, l_idx], label="left")
                ax.plot(torque[:, r_idx], label="right")
                ax.set_title(f"{title}: Left vs Right")
                ax.set_xlabel("Timestep")
                ax.set_ylabel("Torque")
                ax.legend()
            plt.tight_layout()
            plt.show()

            fig, axes = plt.subplots(2, 2, figsize=(15, 8))
            joint_names = [
                ("Shoulder Pitch", 12, 16),
                ("Shoulder Roll", 13, 17),
                ("Shoulder Yaw", 14, 18),
                ("Elbow Pitch", 15, 19),
            ]
            for idx, (title, l_idx, r_idx) in enumerate(joint_names):
                ax = axes[idx // 2, idx % 2]
                ax.plot(torque[:, l_idx], label="left")
                ax.plot(torque[:, r_idx], label="right")
                ax.set_title(f"{title}: Left vs Right")
                ax.set_xlabel("Timestep")
                ax.set_ylabel("Torque")
                ax.legend()
            plt.tight_layout()
            plt.show()
        if PLOT_STEP_LENGTHS:
            step_lengths = np.array(self.step_lengths)
            plt.figure()
            plt.plot(step_lengths, linestyle='-', color='b')
            plt.title("Step Lengths Over Time")
            plt.xlabel("Step Index")
            plt.ylabel("Step Length (m)")
            plt.grid()
            plt.show()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("onnx_path", type=str)
    args = parser.parse_args()

    if "s2" in args.onnx_path:
        robot_version = "s2"
    else:
        raise ValueError("Invalid robot")

    play_mujoco = PlayMujoco(
        onnx_path=args.onnx_path,
        robot_version=robot_version
    )
    curses.wrapper(play_mujoco.play)
